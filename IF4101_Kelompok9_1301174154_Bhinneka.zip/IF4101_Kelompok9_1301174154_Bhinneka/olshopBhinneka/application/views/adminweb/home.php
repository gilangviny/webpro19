<div class="clearfix"></div>
          <div class="row-fluid">
            
            <div class="span12">
              <div class="portlet box blue">
                <div class="portlet-title">
                  <div class="caption"><i class="icon-calendar"></i>Welcome at Admin Dashbord</div>
                  <div class="tools">
                    <a href="" class="collapse"></a>
                    
                  </div>
                </div>
                <div class="portlet-body">
                  <div class="row-fluid">
                    <div class="alert">
                      <p>Hallo! Selamat Datang,</p>
                      <p>Anda Berada Di Area admin untuk mengelola website Adriano
                      gunakan menu yang berada disamping kiri untuk mengelola website.
                      Hubungi pihak admin jika ada beberapa yang kurang dimengerti</p>

                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="clearfix"></div>