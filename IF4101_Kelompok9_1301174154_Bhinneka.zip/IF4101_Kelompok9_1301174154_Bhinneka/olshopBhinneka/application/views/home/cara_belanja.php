<!DOCTYPE html>
<html lang="en">
<head>
	<?php
	foreach ($seo->result_array() as $value) {
		$tittle = $value['tittle'];
		$keyword = $value['keyword'];
		$description = $value['description'];
	}
	?>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keyword" content="<?php echo $keyword;?>">
    <meta name="description" content="<?php echo $description;?>">
    <meta name="author" content="">
    <title>Home | <?php echo $tittle;?></title>
    <link href="<?php echo base_url();?>asset/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>asset/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>asset/css/prettyPhoto.css" rel="stylesheet">
    <link href="<?php echo base_url();?>asset/css/price-range.css" rel="stylesheet">
    <link href="<?php echo base_url();?>asset/css/animate.css" rel="stylesheet">
	<link href="<?php echo base_url();?>asset/css/main.css" rel="stylesheet">
	<link href="<?php echo base_url();?>asset/css/responsive.css" rel="stylesheet">
	<link href="<?php echo base_url();?>asset/css/custom.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="<?php echo base_url();?>asset/js/html5shiv.js"></script>
    <script src="<?php echo base_url();?>asset/js/respond.min.js"></script>
    <![endif]-->       
    <!-- <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png"> -->
</head><!--/head-->

<body>
<header id="header"><!--header-->
				
				<div class="header-middle"><!--header-middle-->
					<!-- <div class="container"> -->
						<div class="row">
							<div class="col-xs-3 col-sm-4" >
								<!-- <div class="logo pull-left">
									<?php
									foreach ($logo->result_array() as $value) {
										$logo = $value['gambar'];
									}
		
									?>
									<a href="<?php echo base_url();?>"><img src="<?php echo base_url();?>images/logo/<?php echo $logo;?>" alt="Bhinneka" /></a>
								</div> -->
								<div class="navbar-header"><a class="navbar-logo" href="/">
									<a href=" <?php echo base_url();?>home/index">
									<img class="img-responsive" src="//static.bmdstatic.com/sf/assets/img/bhinneka-logo.svg" alt="Bhinneka Logo"><img class="hide" src="//static.bmdstatic.com/sf/assets/img/bhinneka-logo-mark.svg" alt="Bhinneka Logo"></a>
									</div>
								<div class="btn-group pull-right">
							<div class="mainmenu pull-left">
									<ul class="nav navbar-nav collapse navbar-collapse">
										<li class="dropdown"><a href="#">Category<i class="fa fa-angle-down"></i></a>
											<ul role="menu" class="sub-menu">
												<?php
												foreach ($kategori->result_array() as $value) { ?>
													
												<li><a href="<?php echo base_url();?>home/kategori/<?php echo $value['id_kategori'];?>"><?php echo $value['nama_kategori'];?></a></li>
												<?php
												}
												?>
												 
											</ul>
										</li> 
										
									
								</div>
								</div>
							</div>
							<div class="col-sm-8">
								<div class="shop-menu pull-center">
									<div class="col-sm-8">
									<?php echo form_open('home/cari');?>
										<div class="search_box pull-center">
											<input type="text" name="cari" placeholder="Search"/>
										</div>
										
									<?php echo form_close();?>
								</div>
							<!-- <div class="mainmenu pull-right">
								<ul class="nav navbar-nav">
									<li><a href="<?php echo base_url();?>home/keranjang"> Keranjang Belanja</a></li>
								</ul>
							</div> -->
								<div class="bt-navbar__right">
									<div class="navbar-cart">
										<a href=" <?php echo base_url();?>home/keranjang">
										<img class="navbar-cart-icon" src="//static.bmdstatic.com/sf/assets/img/icon-shopping-cart.svg" alt="Shopping Cart"> <span class="bt-navbar__badge"></span></a>
									</div>
		
								</div>
		
						</div>
					<!-- </div> -->
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="header-bottom"><!--header-bottom-->
					<div class="container">
						<div class="row">
							<div class="col-sm-9">
								<div class="navbar-header">
									<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
										<span class="sr-only">Toggle navigation</span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
									</button>
								</div>
								<div class="mainmenu pull-left">
									<ul class="nav navbar-nav collapse navbar-collapse">
										<li class="dropdown"><a href="#">Category<i class="fa fa-angle-down"></i></a>
											<ul role="menu" class="sub-menu">
												<?php
												foreach ($kategori->result_array() as $value) { ?>
													
												<li><a href="<?php echo base_url();?>home/kategori/<?php echo $value['id_kategori'];?>"><?php echo $value['nama_kategori'];?></a></li>
												<?php
												}
												?>
												 
											</ul>
										</li> 
										<ul class="nav navbar-nav">
											<li><a href="<?php echo base_url();?>home/tentang_kami"> Tentang Kami</a></li>
											<li><a href="<?php echo base_url();?>home/cara_belanja"> Cara Belanja</a></li>
									
											
										</ul>
										
									</ul>
								</div>
							</div>
				</div><!--/header-bottom-->
			</header><!--/header-->
	
	
	
	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="left-sidebar">
						<h2>Category</h2>
						<div class="panel-group category-products" id="accordian"><!--category-productsr-->
							
							
							<?php

							foreach ($kategori->result_array() as $value) {?>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="<?php echo base_url();?>home/kategori/<?php echo $value['id_kategori'];?>"><?php echo $value['nama_kategori'];?></a></h4>
								</div>
							</div>		
							<?php
							}
							?>	
						
							

						</div><!--/category-products-->
					
						<div class="brands_products"><!--brands_products-->
							<h2>Brands</h2>
							<div class="brands-name">
								<ul class="nav nav-pills nav-stacked">
									<?php
									foreach ($brand->result_array() as $value) { ?>
									<li><a href="<?php echo base_url();?>home/brand/<?php echo $value['id_brand'];?>"> <span class="pull-right"></span><?php echo $value['nama_brand'];?></a></li>
									
									<?php
									}
									?>
									
									
								</ul>
							</div>
						</div><!--/brands_products-->
						
						
						
						<div class="shipping text-center"><!--shipping-->
							<img src="images/home/shipping.jpg" alt="" />
						</div><!--/shipping-->
					
					</div>
				</div>
				
			<div class="col-sm-9">
					<div class="blog-post-area">
						<h2 class="title text-center">Cara Belanja</h2>
						<?php
						foreach ($carabelanja->result_array() as $value) {
							$judul 		= $value['judul'];	
							$deskripsi 	= $value['deskripsi'];	
						}
						?>
						<div class="single-blog-post">
							<h3><?php echo $judul;?></h3>
							
							
							
								<?php echo $deskripsi;?>
							

							
							
						</div>
					</div>
					
				</div>	



			</div>
		</div>
	</section>
	
	<footer id="footer"><!--Footer-->
		<div class="footer-top">
			<div class="container">
				<div class="row">
					<div class="col-sm-2">
						<div class="companyinfo">
							<h2><span>Bhinneka Online</span>-Shop</h2>
							<!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit,sed do eiusmod tempor</p> -->
						</div>
					</div>
					<div class="bt-seo__footer">
                    <div class="container">
                        <div class="row">
                            <div id="SEOWording" class="col-lg-12">
								<h2>Toko Online Pertama &amp; Terpercaya di Indonesia</h2><p>Sebagai toko online terpercaya di Indonesia, Bhinneka yang berdiri sejak 1993 telah dikenal sebagai toko komputer, laptop, gadget, dan aksesori terlengkap. Berbagai produk original tersedia untuk menunjang aktivitas harian, peralatan dapur dan rumah tangga, hingga bisnis atau kebutuhan profesional di kantor maupun tempat usaha. Beragam keperluan IT dan telekomunikasi, perangkat elektronik, sampai hobi dan perawatan tubuh ada di sini, disediakan oleh lebih dari 9.000 supplier. Bhinneka juga telah menjadi Apple Authorized Reseller (AAR), atau pemasar resmi untuk semua produk Apple.</p><p>Selain harga yang bersaing dan berbagai promo diskon dengan e-coupon, nikmati juga pilihan cicilan 0% dengan kartu kredit atau cicilan konvensional (tanpa kartu kredit), dan bebas biaya pengiriman (free ongkir) ke mana saja sesuai ketentuan yang berlaku. Semua disesuaikan untuk kenyamanan Anda berbelanja.</p><p>Tidak hanya melayani pembelian secara online melalui situs bhinneka.com, Bhinneka juga mempunyai toko offline di beberapa kota. Telah ada lima toko di Jakarta (Gunung Sahari, Mangga Dua Mall, Ratu Plaza, Poins Square, dan Cibubur Junction), serta satu di Surabaya (Jalan Dharmahusada). Untuk transaksi melalui telepon, hubungi Sales Agent atau Customer Service kami di (021) 29292828 pada hari dan jam kerja (Senin sampai Sabtu, pukul 08.00-19.00 Wib). Anda tentu juga bisa melakukan pemesanan melalui media sosial Bhinneka di Twitter (@Bhinneka), Facebook (Bhinnekacom), Instagram (@Bhinnekacom), dan LINE (@Bhinneka).</p><p>Demi pelayanan purnajual (after sales) yang berkualitas, Bhinneka juga mempunyai Service Center resmi untuk berbagai produk dan merek. Seperti Acer, Lenovo, HP, Asus, dan HTC. Berlokasi di Jalan Gunung Sahari 73C, Jakarta Pusat, Service Center Bhinneka menerima klaim garansi serta perbaikan komputer, laptop, printer, server, smartphone, tablet, dan berbagai produk lainnya dari seluruh Indonesia. Cukup dengan langsung membawa unit ke Service Center kami, menitipkannya ke toko-toko offline Bhinneka, atau mengirimkannya dengan jasa kurir/ekspedisi.</p><p>Semua ini dihadirkan oleh Bhinneka untuk memberikan pengalaman berbelanja online yang lengkap, bisa diandalkan, dan terpercaya. Karena Bhinneka itu #AsliBikinTenang</p> 
                           </div>
                        </div>
                    </div>
        </div>
            
		
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<p class="pull-left">Copyright © Bhinneka Online Shop. All rights reserved.</p>
					
				</div>
			</div>
		</div> 	
			
	</footer><!--/Footer-->
	

  
    <script src="<?php echo base_url();?>asset/js/jquery.js"></script>
	<script src="<?php echo base_url();?>asset/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url();?>asset/js/jquery.scrollUp.min.js"></script>
	<script src="<?php echo base_url();?>asset/js/price-range.js"></script>
    <script src="<?php echo base_url();?>asset/js/jquery.prettyPhoto.js"></script>
    <script src="<?php echo base_url();?>asset/js/main.js"></script>
</body>
</html>